<?php
include("conexao.php");

$nome = $_POST['nome'];
$sobrenome = $_POST['sobrenome'];
$email = $_POST['email'];
$senha = md5($_POST['senha']);

$comandosql = "INSERT INTO Usuario(nome, sobrenome, email, senha) VALUES('$nome' , '$sobrenome' , '$email', '$senha')";

//echo "   $nome ,   $sobrenome ,   $email ,   $senha";
if(mysqli_query($conexao,$comandosql)){
    echo "usuario cadastrado!";
}else{
    echo "ERRO".mysqli_connect_error($conexao);
}
mysqli_close($conexao);
?>