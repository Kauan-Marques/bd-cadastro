<?php
include("conexao.php");

$nome = $_POST['nome'];
$sobrenome = $_POST['sobrenome'];
$CPF = $_POST['CPF'];
$telefone = $_POST['telefone'];
$email = $_POST['email'];
$senha = md5($_POST['senha']);
$endereco = $_POST['endereco'];
$bairro = $_POST['bairro'];
$UF = $_POST['UF']; 
$CEP = $_POST['CEP'];
$numero = $_POST['numero'];
$cidade = $_POST['cidade'];
$complemento = $_POST['complemento'];

$comandosql = "INSERT INTO Usuario(nome, sobrenome, sexo, CPF, telefone, email, senha, endereco, bairro, UF, CEP, numero, cidade, complemento) VALUES('$nome','$sobrenome','$sexo','$CPF','$telefone','$email','$senha','$endereco','$bairro','$UF','$CEP','$numero','$cidade','$complemento')";

//echo "   $nome ,   $sobrenome , $CPF, $telefone, $email , $senha";
if(mysqli_query($conexao,$comandosql)){
    echo "usuario cadastrado!";
}else{
    echo "ERRO".mysqli_connect_error($conexao);
}
mysqli_close($conexao);
?>

