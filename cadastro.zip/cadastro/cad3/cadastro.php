<?php
include("conexao.php");

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = md5($_POST['senha']);
$confirmarSenha = md5($_POST['confirmarsenha']);
$serieEscolar = $_POST['serieEscolar'];

$comandosql = "INSERT INTO Usuario(nome, email, senha, confirmarsenha, serieEscolar) VALUES('$nome' , '$email', '$senha', '$confirmarSenha', '$serieEscolar')";

//echo "   $nome ,   $sobrenome ,   $email ,   $senha, $confirmarSenha, $serieEscolar";
if(mysqli_query($conexao,$comandosql)){
    echo "usuario cadastrado!";
}else{
    echo "ERRO".mysqli_connect_error($conexao);
}
mysqli_close($conexao);
?>
